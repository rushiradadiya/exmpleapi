import {createStackNavigator,createAppContainer} from 'react-navigation';
import Register from '../component/registrationForm';
import Scanner from '../component/scanID'
import ViewImage from '../component/viewImage'

const appNavigation=createStackNavigator({
    Register,
    ViewImage,
    Scanner
},
    {
        headerMode: 'none',
        navigationOptions: {
            headerVisible: false,
        },
        initialRouteName:'Register'
    },
);

export default createAppContainer(appNavigation)