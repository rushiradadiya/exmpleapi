import React, { Component } from 'react';
import {
    StyleSheet,
    View,
    Dimensions,
    TouchableOpacity
} from 'react-native';
import Camera from 'react-native-camera';
import Icon from 'react-native-vector-icons/FontAwesome'
import IconM from 'react-native-vector-icons/MaterialIcons'

let { height, width } = Dimensions.get('window');
let orientation = height > width ? 'Portrait' : 'Landscape';

export default class ScanID extends Component {
    constructor(props) {
        super(props);
        this.state = {
            orientation
        };
    }

    componentWillMount() {
        Dimensions.addEventListener('change', this.handleOrientationChange);
    }

    componentWillUnmount() {
        Dimensions.removeEventListener('change', this.handleOrientationChange);
    }

    handleOrientationChange = dimensions => {
        ({ height, width } = dimensions.window);
        orientation = height > width ? 'Portrait' : 'Landscape';
        this.setState({ orientation });
    };


    takePicture() {
        this.camera
            .capture()
            .then(data => {
                //data is an object with the file path
                //save the file to app  folder
               // this.saveImage(data.path);
                alert('captured')
            })
            .catch(err => {
                alert('errorcaptured')
                //console.error('capture picture error', err);
            });
    }

    render() {
        return (
            <View style={{ flex: 1 }}>
                <Camera
                    captureTarget={Camera.constants.CaptureTarget.disk}
                    ref={cam => {
                        this.camera = cam;
                    }}
                    style={styles.container}
                    aspect={Camera.constants.Aspect.fill}
                    orientation="auto"
                >
                    <View
                        style={ styles.buttonContainerPortrait}
                    >
                        <TouchableOpacity
                            onPress={() => this.takePicture()}
                            style={styles.buttonPortrait}
                        >
                            <Icon name="camera" size={30} style={{ color: 'white' }} />
                        </TouchableOpacity>

                        <TouchableOpacity
                            onPress={() => this.props.navigation.navigate('Register')}
                            style={ styles.buttonPortrait}
                        >
                            <IconM name="arrow-back" size={30} style={{ color: 'white' }}
                            />
                        </TouchableOpacity>
                    </View>
                </Camera>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1
    },
    buttonContainerPortrait: {
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
        flexDirection: 'row',
        justifyContent: 'center',
        backgroundColor: 'rgba(0, 0, 0, 0.9)'
    },
    buttonContainerLandscape: {
        position: 'absolute',
        bottom: 0,
        top: 0,
        right: 0,
        flexDirection: 'column',
        justifyContent: 'center',
        backgroundColor: 'rgba(0, 0, 0, 0.5)'
    },
    buttonPortrait: {
        backgroundColor: 'transparent',
        padding: 5,
        marginHorizontal: 20,

    },
    buttonLandscape: {
        backgroundColor: 'transparent',
        padding: 5,
        marginVertical: 20
    }
});
